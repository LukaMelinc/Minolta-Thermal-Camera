###########################################################
######## Title: AVMS - seminar 1                   ########
######## Authors: Tilen Tinta, Luka Melinc         ########
######## Program: BMS 1, Avtomatika in Informatika ########
######## Date: May, 2024                           ########
###########################################################

import GUI
if __name__ == "__main__":
    gui = GUI.StartWindow()
